﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Text;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GameDevPOE
{
    public partial class Form2 : Form
    {

        string[] P1data;
        string[] P2data;
        int[] P1values;
        int[] P2values;

        const string FIRE_DRAG_NAME = "Fire Dragon";
        const string ICE_DRAG_NAME = "Ice Dragon";
        const string WIND_DRAG_NAME = "Wind Dragon";
        const string EARTH_DRAG_NAME = "Earth Dragon";

        string turn = "";
        int turnCounter = 0;
        bool P1Block = false, P2Block = false;
        bool P1UseSpecial = false, P2UseSpecial = false;

        public Form2(string[] P1data, int[] P1values, string[] P2data, int[] P2values)
        {
            InitializeComponent();

            this.P1data = P1data;
            this.P2data = P2data;
            this.P1values = P1values;
            this.P2values = P2values;
        }

        private void Form2_Load(object sender, EventArgs e)
        {
            pictureBox1.Image = Properties.Resources.PlayerTurnBack2;
            pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;

            Rest.Hide();

            battleLog.Text = "";
            turn = takeInitiative();
            turnSwitch(turn);

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        //methods for in game actions
        //Random number generator to return a number between 1-6
        private int randomRoll()
        {
            Random diceRoll = new Random();
            int roll = diceRoll.Next(1, 7);
            return roll;
        }

        //Initiative method to determine which player takes the first turn
        //returns which player takes the first turn
        private string takeInitiative()
        {
            int p1Roll = randomRoll();
            int p2Roll = randomRoll();

            while (p1Roll == p2Roll)//while loop to ensure the random numbers are not equal and if they are method will randomRoll their values again
            {
                p1Roll = randomRoll();
                p2Roll = randomRoll();
            }

            string playerTurn = "";

            if (p1Roll > p2Roll)//if statement to check which players roll value was higher
            {
                playerTurn = "P1";
            }

            else
            {
                playerTurn = "P2";
            }

            battleLog.Text += "\r\n" + P1data[0] + " rolled a " + p1Roll + " and " + P2data[0] + " rolled a " + p2Roll + "\r\n" + playerTurn + " takes the initiative";
            battleLog.Text += "\r\n***********************************************************************";

            return playerTurn;
        }

        //method to customize turn player form according to current players turn
        private void turnSwitch(string pTurn)
        {

            if (P1values[0] <= 0)
            {
                battleLog.Text += "\r\n" + P2data[1] + " Defeated " + P1data[1] + " and Wins the game!!!";
                Attack.Enabled = false;
                SpAttack.Enabled = false;
                Block.Enabled = false;
            }

            else if (P2values[0] <= 0)
            {
                battleLog.Text += "\r\n" + P1data[1] + " Defeated " + P2data[1] + " and Wins the game!!!";
                Attack.Enabled = false;
                SpAttack.Enabled = false;
                Block.Enabled = false;
            }

            else 
            {
                if (pTurn == "P1")
                {
                    lblCrntPlayerName.Text = P1data[0] + ", P" + P1data[3];
                    lblCrntDragonName.Text = P1data[1] + ",\nThe " + P1data[2];
                    lblCrntHP.Text = "HP: " + P1values[0];

                    lblStats.Text = "Attack: " + P1values[1] + "\nSpecial Attack: " + P1values[2] + "\nBlock: " + P1values[3];

                    switch (P1data[2])
                    {
                        case FIRE_DRAG_NAME:
                            crntPlayerPic.Image = Properties.Resources.FireDragon;
                            crntPlayerPic.SizeMode = PictureBoxSizeMode.StretchImage;
                            break;
                        case ICE_DRAG_NAME:
                            crntPlayerPic.Image = Properties.Resources.IceDragon;
                            crntPlayerPic.SizeMode = PictureBoxSizeMode.StretchImage;
                            break;
                        case EARTH_DRAG_NAME:
                            crntPlayerPic.Image = Properties.Resources.EarthDragon;
                            crntPlayerPic.SizeMode = PictureBoxSizeMode.StretchImage;
                            break;
                        case WIND_DRAG_NAME:
                            crntPlayerPic.Image = Properties.Resources.WindDragon;
                            crntPlayerPic.SizeMode = PictureBoxSizeMode.StretchImage;
                            break;
                    }

                    lblOppPlayerName.Text = P2data[0] + ", P" + P2data[3];
                    lblOppDragonName.Text = P2data[1] + ",\nThe " + P2data[2];
                    oppDragonHp.Text = "HP: " + P2values[0];

                    switch (P2data[2])
                    {
                        case FIRE_DRAG_NAME:
                            oppPlayerPic.Image = Properties.Resources.FireDragon;
                            oppPlayerPic.SizeMode = PictureBoxSizeMode.StretchImage;
                            break;
                        case ICE_DRAG_NAME:
                            oppPlayerPic.Image = Properties.Resources.IceDragon;
                            oppPlayerPic.SizeMode = PictureBoxSizeMode.StretchImage;
                            break;
                        case EARTH_DRAG_NAME:
                            oppPlayerPic.Image = Properties.Resources.EarthDragon;
                            oppPlayerPic.SizeMode = PictureBoxSizeMode.StretchImage;
                            break;
                        case WIND_DRAG_NAME:
                            oppPlayerPic.Image = Properties.Resources.WindDragon;
                            oppPlayerPic.SizeMode = PictureBoxSizeMode.StretchImage;
                            break;
                    }

                }

                else
                {

                    lblCrntPlayerName.Text = P2data[0] + ", " + P2data[3];
                    lblCrntDragonName.Text = P2data[1] + ",\nThe " + P2data[2];
                    lblCrntHP.Text = "HP: " + P2values[0];

                    lblStats.Text = "Attack: " + P2values[1] + "\nSpecial Attack: " + P2values[2] + "\nBlock: " + P2values[3];

                    switch (P2data[2])
                    {
                        case FIRE_DRAG_NAME:
                            crntPlayerPic.Image = Properties.Resources.FireDragon;
                            crntPlayerPic.SizeMode = PictureBoxSizeMode.StretchImage;
                            break;
                        case ICE_DRAG_NAME:
                            crntPlayerPic.Image = Properties.Resources.IceDragon;
                            crntPlayerPic.SizeMode = PictureBoxSizeMode.StretchImage;
                            break;
                        case EARTH_DRAG_NAME:
                            crntPlayerPic.Image = Properties.Resources.EarthDragon;
                            crntPlayerPic.SizeMode = PictureBoxSizeMode.StretchImage;
                            break;
                        case WIND_DRAG_NAME:
                            crntPlayerPic.Image = Properties.Resources.WindDragon;
                            crntPlayerPic.SizeMode = PictureBoxSizeMode.StretchImage;
                            break;
                    }

                    lblOppPlayerName.Text = P1data[0] + ", " + P1data[3];
                    lblOppDragonName.Text = P1data[1] + "\nThe " + P1data[2];
                    oppDragonHp.Text = "HP: " + P1values[0];

                    switch (P1data[2])
                    {
                        case FIRE_DRAG_NAME:
                            oppPlayerPic.Image = Properties.Resources.FireDragon;
                            oppPlayerPic.SizeMode = PictureBoxSizeMode.StretchImage;
                            break;
                        case ICE_DRAG_NAME:
                            oppPlayerPic.Image = Properties.Resources.IceDragon;
                            oppPlayerPic.SizeMode = PictureBoxSizeMode.StretchImage;
                            break;
                        case EARTH_DRAG_NAME:
                            oppPlayerPic.Image = Properties.Resources.EarthDragon;
                            oppPlayerPic.SizeMode = PictureBoxSizeMode.StretchImage;
                            break;
                        case WIND_DRAG_NAME:
                            oppPlayerPic.Image = Properties.Resources.WindDragon;
                            oppPlayerPic.SizeMode = PictureBoxSizeMode.StretchImage;
                            break;
                    }

                }

                if (pTurn == "P1")
                {
                    battleLog.Text += "\r\n" + P1data[0] + "'s Turn \r\n***********************************************************************";
                }

                else
                {
                    battleLog.Text += "\r\n" + P2data[0] + "'s Turn \r\n***********************************************************************";
                }

                if (pTurn == "P1" && P1UseSpecial)
                {
                    Attack.Enabled = false;
                    SpAttack.Enabled = false;
                    Block.Enabled = false;
                    Rest.Show();
                    Rest.Enabled = true;
                    P1UseSpecial = false;
                    battleLog.Text += "\r\n" + P1data[1] + " is tired and must rest";
                }

                else if (pTurn == "P2" && P2UseSpecial)
                {
                    Attack.Enabled = false;
                    SpAttack.Enabled = false;
                    Block.Enabled = false;
                    Rest.Show();
                    Rest.Enabled = true;
                    P2UseSpecial = false;
                    battleLog.Text += "\r\n" + P2data[1] + " is tired and must rest";
                }
            }

            turnCounter++;
        }

        //method to switch current players turn value
        private void nextTurn(string nextTurn)
        {
            if (nextTurn == "P1")
            {
                nextTurn = "P2";
            }

            else
            {
                nextTurn = "P1";
            }

            turn = nextTurn;

            if (turnCounter >= 2)
            {
                turnCounter = 0;
                turn = takeInitiative();
            }

            turnSwitch(turn);
        }

        //method to set blocking bool to true
        private void Blockk(string player)// accepts current player (string turn) as parameter
        {
            if (player == "P1")
            {
                P1Block = true;
                battleLog.Text += "\r\n" + P1data[0] + " blocks the next attack!\r\n***********************************************************************";
            }

            else
            {
                P2Block = true;
                battleLog.Text += "\r\n" + P2data[0] + " blocks the next attack!\r\n***********************************************************************";
            }

            nextTurn(player);
        }

        //method to use attack and deal damage to other player
        private void Attackk(string player)
        {
            int blocked = 0;

            if (player == "P1")
            {
                if (P2Block)
                {

                    blocked = P1values[1] - P2values[3];

                    if (blocked < 0 )
                    {
                        blocked = 0;
                    }
                    P2values[0] -= blocked;
                    P2Block = false;
                    battleLog.Text += "\r\n" + P1data[1] + " attacks " + P2data[1] + " and deals " + (blocked) + " damage!\r\n***********************************************************************";
                }
                else
                {
                    P2values[0] -= P1values[1];
                    battleLog.Text += "\r\n" + P1data[1] + " attacks " + P2data[1] + " and deals " + (P1values[1]) + " damage!\r\n***********************************************************************";
                }
            }

            else
            {
                if (P1Block)
                {
                    blocked = P2values[1] - P1values[3];

                    if (blocked < 0)
                    {
                        blocked = 0;
                    }

                    P1values[0] -= blocked;
                    P1Block = false;
                    battleLog.Text += "\r\n" + P2data[1] + " attacks " + P1data[1] + " and deals " + (blocked) + " damage!\r\n***********************************************************************";
                }
                else
                {
                    P1values[0] -= P2values[1];
                    battleLog.Text += "\r\n" + P2data[1] + " attacks " + P1data[1] + " and deals " + (P2values[1]) + " damage!\r\n***********************************************************************";

                }
            }

            nextTurn(player);
        }

        //Method to use special attack and set spAttack bool to true
        private void SpecialAtt(string player)
        {

            int blocked = 0;

            if (player == "P1")
            {
                if (P2Block)
                {
                    blocked = P1values[2] - P2values[3];

                    if (blocked < 0)
                    {
                        blocked = 0;
                    }

                    P2values[0] -= blocked;
                    P2Block = false;
                    battleLog.Text += "\r\n" + P1data[1] + " special attacks " + P2data[1] + " and deals " + (blocked) + " damage!\r\n***********************************************************************";
                }
                else
                {
                    P2values[0] -= P1values[2];
                    battleLog.Text += "\r\n" + P1data[1] + " special attacks " + P2data[1] + " and deals " + (P1values[2]) + " damage!\r\n***********************************************************************";
                }

                P1UseSpecial = true;
            }

            else
            {
                if (P1Block)
                {
                    blocked = P2values[2] - P1values[3];

                    if (blocked < 0)
                    {
                        blocked = 0;
                    }

                    P1values[0] -= blocked;
                    P1Block = false;
                    battleLog.Text += "\r\n" + P2data[1] + " special attacks " + P1data[1] + " and deals " + (blocked) + " damage!\r\n***********************************************************************";
                }
                else
                {
                    P1values[0] -= P2values[2];
                    battleLog.Text += "\r\n" + P2data[1] + " special attacks " + P1data[1] + " and deals " + (P2values[2]) + " damage!\r\n***********************************************************************";
                }

                P2UseSpecial = true;
            }

            nextTurn(player);
        }

        //method to activate rest button 
        private void Restt(string player)
        {
            Attack.Enabled = true;
            SpAttack.Enabled = true;
            Block.Enabled = true;
            Rest.Hide();
            nextTurn(player);
        }

        private void Attack_Click(object sender, EventArgs e)
        {
            Attackk(turn);
        }

        private void SpAttack_Click(object sender, EventArgs e)
        {
            SpecialAtt(turn);
        }

        private void Block_Click(object sender, EventArgs e)
        {
            Blockk(turn);
        }

        private void Rest_Click(object sender, EventArgs e)
        {
            Restt(turn);
        }

        private void Rest_Click_1(object sender, EventArgs e)
        {
            Restt(turn);
        }

        private void Rest_Click_2(object sender, EventArgs e)
        {
            Restt(turn);
        }

        private void Rest_Click_3(object sender, EventArgs e)
        {
            Restt(turn);
        }
    }
}
